# ### factwise-python/user_impl.py
#
# import json
# import os
# from user_base import UserBase
#
# DB_PATH = "db/user_data.json"
#
# class UserImpl(UserBase):
#     def create_user(self, input_json: str) -> str:
#         try:
#             user = json.loads(input_json)
#             if "id" not in user or "name" not in user or "email" not in user:
#                 raise ValueError("Missing required fields: id, name, email")
#
#             if not os.path.exists(DB_PATH):
#                 with open(DB_PATH, 'w') as f:
#                     json.dump([], f)
#
#             with open(DB_PATH, "r") as f:
#                 users = json.load(f)
#
#             if any(u["id"] == user["id"] for u in users):
#                 raise ValueError("User with this ID already exists")
#
#             users.append(user)
#             with open(DB_PATH, "w") as f:
#                 json.dump(users, f, indent=2)
#
#             return json.dumps({"status": "success", "message": "User created"})
#
#         except Exception as e:
#             return json.dumps({"status": "error", "message": str(e)})
#
#     def get_user(self, input_json: str) -> str:
#         try:
#             data = json.loads(input_json)
#             user_id = data.get("id")
#             if user_id is None:
#                 raise ValueError("Missing 'id'")
#
#             with open(DB_PATH, "r") as f:
#                 users = json.load(f)
#
#             for user in users:
#                 if user["id"] == user_id:
#                     return json.dumps({"status": "success", "user": user})
#
#             return json.dumps({"status": "error", "message": "User not found"})
#
#         except Exception as e:
#             return json.dumps({"status": "error", "message": str(e)})
#
#     def delete_user(self, input_json: str) -> str:
#         try:
#             data = json.loads(input_json)
#             user_id = data.get("id")
#             if user_id is None:
#                 raise ValueError("Missing 'id'")
#
#             with open(DB_PATH, "r") as f:
#                 users = json.load(f)
#
#             new_users = [u for u in users if u["id"] != user_id]
#
#             if len(new_users) == len(users):
#                 return json.dumps({"status": "error", "message": "User not found"})
#
#             with open(DB_PATH, "w") as f:
#                 json.dump(new_users, f, indent=2)
#
#             return json.dumps({"status": "success", "message": "User deleted"})
#
#         except Exception as e:
#             return json.dumps({"status": "error", "message": str(e)})
#
# ### factwise-python/project_board_impl.py (basic skeleton)
#
# from project_board_base import ProjectBoardBase
#
# class ProjectBoardImpl(ProjectBoardBase):
#     def create_board(self, input_json: str) -> str:
#         return "{}"  # implement as needed
import json
import os
import uuid
from datetime import datetime
from project_board_base import ProjectBoardBase

DB_BOARD = "db/boards.json"
DB_TASK = "db/tasks.json"
OUT_DIR = "out"

class ProjectBoardImpl(ProjectBoardBase):
    def __init__(self):
        os.makedirs(os.path.dirname(DB_BOARD), exist_ok=True)
        os.makedirs(os.path.dirname(DB_TASK), exist_ok=True)
        os.makedirs(OUT_DIR, exist_ok=True)
        self._load_boards()
        self._load_tasks()

    def _load_boards(self):
        try:
            with open(DB_BOARD, 'r') as f:
                self.boards = json.load(f)
        except FileNotFoundError:
            self.boards = []

    def _save_boards(self):
        with open(DB_BOARD, 'w') as f:
            json.dump(self.boards, f, indent=2)

    def _load_tasks(self):
        try:
            with open(DB_TASK, 'r') as f:
                self.tasks = json.load(f)
        except FileNotFoundError:
            self.tasks = []

