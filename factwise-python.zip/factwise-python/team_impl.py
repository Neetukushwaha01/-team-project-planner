
import json
from team_base import TeamBase  # Make sure this import is correct

class TeamImpl(TeamBase):
    def __init__(self):
        self.team_data_file = "teams.json"
        self.load_data()

    def load_data(self):
        try:
            with open(self.team_data_file, 'r') as file:
                self.teams = json.load(file)
        except FileNotFoundError:
            self.teams = []

    def save_data(self):
        with open(self.team_data_file, 'w') as file:
            json.dump(self.teams, file)

    def create_team(self, request: str) -> str:
        team_details = json.loads(request)
        new_team = {
            "id": str(len(self.teams) + 1),
            "name": team_details["name"],
            "description": team_details["description"],
            "admin": team_details["admin"],
            "creation_time": "2025-05-08T12:00:00"
        }
        self.teams.append(new_team)
        self.save_data()
        return json.dumps({"id": new_team["id"]})

    def list_teams(self) -> str:
        return json.dumps(self.teams)

    def describe_team(self, request: str) -> str:
        team_id = json.loads(request)["id"]
        team = next((t for t in self.teams if t["id"] == team_id), None)
        if team:
            return json.dumps(team)
        return json.dumps({"error": "Team not found"})

    def update_team(self, request: str) -> str:
        updated_details = json.loads(request)
        team_id = updated_details["id"]
        updated_team = updated_details["team"]
        team = next((t for t in self.teams if t["id"] == team_id), None)
        if team:
            team["name"] = updated_team["name"]
            team["description"] = updated_team["description"]
            team["admin"] = updated_team["admin"]
            self.save_data()
            return json.dumps({"message": "Team updated successfully"})
        return json.dumps({"error": "Team not found"})

    def add_users_to_team(self, request: str):
        team_details = json.loads(request)
        team_id = team_details["id"]
        users_to_add = team_details["users"]
        team = next((t for t in self.teams if t["id"] == team_id), None)
        if team:
            team["users"] = team.get("users", []) + users_to_add
            self.save_data()
            return json.dumps({"message": "Users added successfully"})
        return json.dumps({"error": "Team not found"})

    def remove_users_from_team(self, request: str):
        team_details = json.loads(request)
        team_id = team_details["id"]
        users_to_remove = team_details["users"]
        team = next((t for t in self.teams if t["id"] == team_id), None)
        if team:
            team["users"] = [user for user in team["users"] if user not in users_to_remove]
            self.save_data()
            return json.dumps({"message": "Users removed successfully"})
        return json.dumps({"error": "Team not found"})

    def list_team_users(self, request: str):
        team_id = json.loads(request)["id"]
        team = next((t for t in self.teams if t["id"] == team_id), None)
        if team and "users" in team:
            return json.dumps([{"id": user, "name": f"User {user}", "display_name": f"User {user}"} for user in team["users"]])
        return json.dumps({"error": "Team not found or no users in team"})
