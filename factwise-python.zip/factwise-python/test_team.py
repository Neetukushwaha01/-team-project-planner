from team_impl import TeamImpl
import json
import sys

def print_menu():
    """Function to display the available options."""
    print("\nTeam Management Options:")
    print("1. Create Team")
    print("2. List Teams")
    print("3. Describe Team")
    print("4. Update Team")
    print("5. Add Users to Team")
    print("6. Remove Users from Team")
    print("7. List Team Users")
    print("8. Exit")
    print("\nPlease choose an option (1-8): ", end="")

def create_team(team_impl):
    """Function to create a team."""
    name = input("Enter team name: ")
    description = input("Enter team description: ")
    admin = input("Enter admin user ID: ")

    team_details = {
        "name": name,
        "description": description,
        "admin": admin
    }

    request = json.dumps(team_details)
    response = team_impl.create_team(request)
    print("Response:", response)

def list_teams(team_impl):
    """Function to list all teams."""
    response = team_impl.list_teams()
    print("Response:", response)

def describe_team(team_impl):
    """Function to describe a specific team."""
    team_id = input("Enter team ID to describe: ")
    request = json.dumps({"id": team_id})
    response = team_impl.describe_team(request)
    print("Response:", response)

def update_team(team_impl):
    """Function to update a team's details."""
    team_id = input("Enter team ID to update: ")
    name = input("Enter new team name: ")
    description = input("Enter new team description: ")
    admin = input("Enter new admin user ID: ")

    updated_details = {
        "id": team_id,
        "team": {
            "name": name,
            "description": description,
            "admin": admin
        }
    }

    request = json.dumps(updated_details)
    response = team_impl.update_team(request)
    print("Response:", response)

def add_users_to_team(team_impl):
    """Function to add users to a team."""
    team_id = input("Enter team ID to add users: ")
    users = input("Enter user IDs to add (comma separated): ").split(",")
    request = json.dumps({
        "id": team_id,
        "users": users
    })
    response = team_impl.add_users_to_team(request)
    print("Response:", response)

def remove_users_from_team(team_impl):
    """Function to remove users from a team."""
    team_id = input("Enter team ID to remove users: ")
    users = input("Enter user IDs to remove (comma separated): ").split(",")
    request = json.dumps({
        "id": team_id,
        "users": users
    })
    response = team_impl.remove_users_from_team(request)
    print("Response:", response)

def list_team_users(team_impl):
    """Function to list users of a team."""
    team_id = input("Enter team ID to list users: ")
    request = json.dumps({"id": team_id})
    response = team_impl.list_team_users(request)
    print("Response:", response)

def main():
    """Main function to run the text-based menu."""
    team_impl = TeamImpl()

    while True:
        print_menu()
        choice = input()

        if choice == "1":
            create_team(team_impl)
        elif choice == "2":
            list_teams(team_impl)
        elif choice == "3":
            describe_team(team_impl)
        elif choice == "4":
            update_team(team_impl)
        elif choice == "5":
            add_users_to_team(team_impl)
        elif choice == "6":
            remove_users_from_team(team_impl)
        elif choice == "7":
            list_team_users(team_impl)
        elif choice == "8":
            print("Exiting... Goodbye!")
            sys.exit()
        else:
            print("Invalid option. Please choose a number between 1 and 8.")

if __name__ == "__main__":
    main()
