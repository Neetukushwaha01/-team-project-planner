# # import json
# # from user_impl import UserImpl
# #
# # # Create an instance of UserImpl class
# # u = UserImpl()
# #
# # # Create user (without providing 'id', so it will be auto-generated)
# # print(u.create_user(json.dumps({"name": "Neetu", "email": "neetu@example.com"})))
# #
# # # Get user (use the correct ID that was generated above)
# # print(u.get_user(json.dumps({"id": 1})))
# #
# # # Delete user (again using the same ID as above)
# # print(u.delete_user(json.dumps({"id": 1})))
#
# import json
# from user_impl import UserImpl
#
# u = UserImpl()
#
# # Create
# print(u.create_user(json.dumps({"name": "neetu", "display_name": "Neetu Kushwaha"})))
#
# # List
# print(u.list_users())
#
# # Describe
# print(u.describe_user(json.dumps({"id": "1"})))
#
# # Update
# print(u.update_user(json.dumps({"id": "1", "user": {"display_name": "Updated Neetu"}})))
#
# # Get Teams
# print(u.get_user_teams(json.dumps({"id": "1"})))
import json
from user_impl import UserImpl

u = UserImpl()

# Create a new user
response = u.create_user(json.dumps({"name": "Neetu", "display_name": "Neetu Kushwaha"}))
print(response)

# List all users
print(u.list_users())

# Describe a user by ID (make sure user exists with that ID)
response = u.describe_user(json.dumps({"id": "1"}))  # Replace with correct ID if needed
print(response)

# Update a user's display name
response = u.update_user(json.dumps({"id": "1", "user": {"display_name": "Updated Neetu"}}))  # Replace with correct ID if needed
print(response)

# Get teams associated with a user
response = u.get_user_teams(json.dumps({"id": "1"}))  # Replace with correct ID if needed
print(response)
