# import json
# import os
#
# DB_PATH = "db/user_data.json"
#
# class UserImpl:
#     def create_user(self, input_json: str) -> str:
#         try:
#             user = json.loads(input_json)
#
#             # Ensure user has name and email
#             if "name" not in user or "email" not in user:
#                 raise ValueError("Missing required fields: name, email")
#
#             # Automatically generate user ID if not provided
#             if "id" not in user:
#                 with open(DB_PATH, "r") as f:
#                     users = json.load(f)
#                 # Generate new ID based on the highest existing ID
#                 if users:
#                     user["id"] = max(u["id"] for u in users) + 1
#                 else:
#                     user["id"] = 1  # If no users exist, start with ID 1
#
#             # Check if file exists, if not create it
#             if not os.path.exists(DB_PATH):
#                 with open(DB_PATH, 'w') as f:
#                     json.dump([], f)
#
#             # Load existing users from file
#             with open(DB_PATH, "r") as f:
#                 users = json.load(f)
#
#             # Add new user and save to file
#             users.append(user)
#             with open(DB_PATH, "w") as f:
#                 json.dump(users, f, indent=2)
#
#             return json.dumps({"status": "success", "user": user})  # Return created user with ID
#
#         except Exception as e:
#             return json.dumps({"status": "error", "message": str(e)})
#
#     def get_user(self, input_json: str) -> str:
#         try:
#             data = json.loads(input_json)
#             user_id = data.get("id")
#             if user_id is None:
#                 raise ValueError("Missing 'id'")
#
#             with open(DB_PATH, "r") as f:
#                 users = json.load(f)
#
#             for user in users:
#                 if user["id"] == user_id:
#                     return json.dumps({"status": "success", "user": user})
#
#             return json.dumps({"status": "error", "message": "User not found"})
#
#         except Exception as e:
#             return json.dumps({"status": "error", "message": str(e)})
#
#     def delete_user(self, input_json: str) -> str:
#         try:
#             data = json.loads(input_json)
#             user_id = data.get("id")
#             if user_id is None:
#                 raise ValueError("Missing 'id'")
#
#             with open(DB_PATH, "r") as f:
#                 users = json.load(f)
#
#             new_users = [u for u in users if u["id"] != user_id]
#
#             if len(new_users) == len(users):
#                 return json.dumps({"status": "error", "message": "User not found"})
#
#             with open(DB_PATH, "w") as f:
#                 json.dump(new_users, f, indent=2)
#
#             return json.dumps({"status": "success", "message": "User deleted"})
#
#         except Exception as e:
#             return json.dumps({"status": "error", "message": str(e)})



# import json
# import os
# from datetime import datetime
#
# DB_PATH = "db/user_data.json"
#
#
# class UserImpl:
#     def __init__(self):
#         if not os.path.exists(DB_PATH):
#             with open(DB_PATH, "w") as f:
#                 json.dump([], f)
#
#     def load_users(self):
#         with open(DB_PATH, "r") as f:
#             return json.load(f)
#
#     def save_users(self, users):
#         with open(DB_PATH, "w") as f:
#             json.dump(users, f, indent=2)
#
#     def create_user(self, request: str) -> str:
#         try:
#             data = json.loads(request)
#             name = data["name"]
#             display_name = data["display_name"]
#
#             # Constraints
#             if len(name) > 64:
#                 return json.dumps({"error": "Name max 64 characters"})
#             if len(display_name) > 64:
#                 return json.dumps({"error": "Display name max 64 characters"})
#
#             users = self.load_users()
#             if any(u["name"] == name for u in users):
#                 return json.dumps({"error": "User name must be unique"})
#
#             user_id = str(len(users) + 1)
#             new_user = {
#                 "id": user_id,
#                 "name": name,
#                 "display_name": display_name,
#                 "creation_time": datetime.now().isoformat()
#             }
#             users.append(new_user)
#             self.save_users(users)
#             return json.dumps({"id": user_id})
#
#         except Exception as e:
#             return json.dumps({"error": str(e)})
#
#     def describe_user(self, request: str) -> str:
#         try:
#             data = json.loads(request)
#             user_id = data["id"]
#             users = self.load_users()
#             user = next((u for u in users if u["id"] == user_id), None)
#             if not user:
#                 return json.dumps({"error": "User not found"})
#
#             return json.dumps({
#                 "name": user["name"],
#                 "description": f"User {user['name']} profile",
#                 "creation_time": user["creation_time"]
#             })
#
#         except Exception as e:
#             return json.dumps({"error": str(e)})
#
#     def list_users(self) -> str:
#         users = self.load_users()
#         return json.dumps([
#             {
#                 "name": u["name"],
#                 "display_name": u["display_name"],
#                 "creation_time": u["creation_time"]
#             } for u in users
#         ], indent=2)
#
#     def update_user(self, request: str) -> str:
#         try:
#             data = json.loads(request)
#             user_id = data["id"]
#             new_info = data["user"]
#
#             users = self.load_users()
#             user = next((u for u in users if u["id"] == user_id), None)
#             if not user:
#                 return json.dumps({"error": "User not found"})
#
#             if "name" in new_info and new_info["name"] != user["name"]:
#                 return json.dumps({"error": "User name cannot be updated"})
#
#             if len(new_info.get("name", user["name"])) > 64:
#                 return json.dumps({"error": "Name max 64 characters"})
#
#             if len(new_info.get("display_name", "")) > 128:
#                 return json.dumps({"error": "Display name max 128 characters"})
#
#             user["display_name"] = new_info["display_name"]
#             self.save_users(users)
#             return json.dumps({"message": "User updated"})
#
#         except Exception as e:
#             return json.dumps({"error": str(e)})
#
#     def get_user_teams(self, request: str) -> str:
#         try:
#             data = json.loads(request)
#             user_id = data["id"]
#
#             team_path = "db/team_data.json"
#             if not os.path.exists(team_path):
#                 return json.dumps([])
#
#             with open(team_path, "r") as f:
#                 teams = json.load(f)
#
#             user_teams = [
#                 {
#                     "name": t["name"],
#                     "description": t["description"],
#                     "creation_time": t["creation_time"]
#                 } for t in teams if "users" in t and user_id in t["users"]
#             ]
#             return json.dumps(user_teams, indent=2)
#
#         except Exception as e:
#             return json.dumps({"error": str(e)})




import json
import os
from datetime import datetime
import uuid

DB_PATH = "db/user_data.json"
TEAM_DB_PATH = "db/team_data.json"

class UserImpl:
    def __init__(self):
        if not os.path.exists(DB_PATH):
            with open(DB_PATH, "w") as f:
                json.dump([], f)

    def load_users(self):
        with open(DB_PATH, "r") as f:
            return json.load(f)

    def save_users(self, users):
        with open(DB_PATH, "w") as f:
            json.dump(users, f, indent=2)

    def create_user(self, request: str) -> str:
        try:
            data = json.loads(request)
            name = data["name"]
            display_name = data["display_name"]

            # Constraints
            if len(name) > 64:
                return json.dumps({"error": "Name max 64 characters"})
            if len(display_name) > 64:
                return json.dumps({"error": "Display name max 64 characters"})

            users = self.load_users()
            if any(u["name"] == name for u in users):
                return json.dumps({"error": "User name must be unique"})

            # Auto-generate a unique user ID using UUID
            user_id = str(uuid.uuid4())  # Using UUID for unique ID generation
            new_user = {
                "id": user_id,
                "name": name,
                "display_name": display_name,
                "creation_time": datetime.now().isoformat()
            }
            users.append(new_user)
            self.save_users(users)
            return json.dumps({"id": user_id})

        except Exception as e:
            return json.dumps({"error": str(e)})

    def describe_user(self, request: str) -> str:
        try:
            data = json.loads(request)
            user_id = data["id"]
            users = self.load_users()
            user = next((u for u in users if u["id"] == user_id), None)
            if not user:
                return json.dumps({"error": "User not found"})

            return json.dumps({
                "name": user["name"],
                "description": f"User {user['name']} profile",
                "creation_time": user["creation_time"]
            })

        except Exception as e:
            return json.dumps({"error": str(e)})

    def list_users(self) -> str:
        users = self.load_users()
        return json.dumps([{
            "name": u["name"],
            "display_name": u["display_name"],
            "creation_time": u["creation_time"]
        } for u in users], indent=2)

    def update_user(self, request: str) -> str:
        try:
            data = json.loads(request)
            user_id = data["id"]
            new_info = data["user"]

            users = self.load_users()
            user = next((u for u in users if u["id"] == user_id), None)
            if not user:
                return json.dumps({"error": "User not found"})

            if "name" in new_info and new_info["name"] != user["name"]:
                return json.dumps({"error": "User name cannot be updated"})

            if len(new_info.get("name", user["name"])) > 64:
                return json.dumps({"error": "Name max 64 characters"})

            if len(new_info.get("display_name", "")) > 128:
                return json.dumps({"error": "Display name max 128 characters"})

            user["display_name"] = new_info["display_name"]
            self.save_users(users)
            return json.dumps({"message": "User updated"})

        except Exception as e:
            return json.dumps({"error": str(e)})

    def get_user_teams(self, request: str) -> str:
        try:
            data = json.loads(request)
            user_id = data["id"]

            # Check if team file exists
            if not os.path.exists(TEAM_DB_PATH):
                return json.dumps([])

            with open(TEAM_DB_PATH, "r") as f:
                teams = json.load(f)

            # Find teams the user is part of
            user_teams = [
                {
                    "name": t["name"],
                    "description": t["description"],
                    "creation_time": t["creation_time"]
                } for t in teams if "users" in t and user_id in t["users"]
            ]
            return json.dumps(user_teams, indent=2)

        except Exception as e:
            return json.dumps({"error": str(e)})
